package net.synapticweb.callrecorder;


public class Config {
	static final public String FILE_PROVIDER = "net.synapticweb.callrecorder.full.fileprovider";
}