## 1.1.2
- Audio source is now selectable by the user.

## 1.1.1
- Recordings name now contain the full date with year and no "Recording" prefix.
- The recordings listings are now retrieved ordered by date descending.
- Removed arrows (type of call) from hidden number contacts recordings.


## 1.0.0
- Reached production development stage